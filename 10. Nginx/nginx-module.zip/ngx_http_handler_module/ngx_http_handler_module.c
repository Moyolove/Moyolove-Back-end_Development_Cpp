


#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>


#include <arpa/inet.h>
#include <netinet/in.h>

#define ENABLE_RBTREE		1



typedef struct {
	int count;
	struct in_addr addr;
} ngx_pv_table;

ngx_pv_table pv_table[256] = {0}; //


typedef struct {

	ngx_rbtree_t rbtree;
	ngx_rbtree_node_t sentienl;

} ngx_http_pagecount_shm_t;


typedef struct {

	size_t shmsize;

	ngx_slab_pool_t *shpool; // no init
	
	ngx_http_pagecount_shm_t *sh;
	
} ngx_http_pagecount_conf_t;


char *ngx_http_handler_count_set(ngx_conf_t *cf, ngx_command_t *cmd, void *conf);


void ngx_encode_http_page(char *html) {

	sprintf(html, "<h1>Flamingo, Apollo, liaoliao, bing</h1>");

	strcat(html, "<h2>");

	int i = 0;
	for (i = 0;i < 256;i ++) {

		if (pv_table[i].count != 0) {

			char str[INET_ADDRSTRLEN] = {0};
			char buffer[128] = {0};
			sprintf(buffer, "req from : %s, count: %d <br/>",
				inet_ntop(AF_INET, &pv_table[i].addr, str, sizeof(str)),
				pv_table[i].count);

			strcat(html, buffer);
		}
		
	}
	
	strcat(html, "</h2>");

} 

ngx_int_t ngx_http_count_handler(ngx_http_request_t *r) {

	// ip, count
	// 192.168.199.23
	struct sockaddr_in *cliaddr = (struct sockaddr_in*)r->connection->sockaddr;


#if ENABLE_RBTREE

	ngx_http_pagecount_conf_t *conf = ngx_http_get_module_loc_conf(r, ngx_http_handler_module);

	

#else
	// search
	int idx = cliaddr->sin_addr.s_addr >> 24;

	pv_table[idx].count ++;
	memcpy(&pv_table[idx].addr, &cliaddr->sin_addr, sizeof(cliaddr->sin_addr));

	// encode page
	u_char html[1024] = {0};
	int len = sizeof(html);
	
	ngx_encode_http_page((char*)html);
#endif
	// send http response
	r->headers_out.status = 200;
	ngx_str_set(&r->headers_out.content_type, "text/html");
	ngx_http_send_header(r);


	ngx_buf_t *b = ngx_palloc(r->pool, sizeof(ngx_buf_t));
	b->pos = html;
	b->last = html + len;
	b->memory = 1;
	b->last_buf = 1;

	ngx_chain_t out;
	out.buf = b;
	out.next = NULL;
	
	return ngx_http_output_filter(r, &out);

}







ngx_command_t ngx_http_handler_module_cmd[] = {
	{
		ngx_string("count"),
		NGX_HTTP_LOC_CONF | NGX_CONF_NOARGS,
		ngx_http_handler_count_set,
		NGX_HTTP_LOC_CONF_OFFSET,
		0,
		NULL,
	},
	ngx_null_command
};


// nginx -c conf/nginx.conf
// module 

void *ngx_http_handler_module_create_loc_conf(ngx_conf_t *cf) {

	ngx_http_pagecount_conf_t *conf = ngx_palloc(cf->pool, sizeof(ngx_http_pagecount_conf_t));
	if (conf == NULL) return NULL;

	conf->shmsize = 0;

	return conf;
}


static ngx_http_module_t ngx_http_handler_module_ctx = {

	NULL,
	NULL,

	NULL,
	NULL,

	ngx_http_handler_module_create_loc_conf,
	NULL,

	NULL,
	NULL,

};


ngx_module_t ngx_http_handler_module = {
	NGX_MODULE_V1,
	&ngx_http_handler_module_ctx,
	ngx_http_handler_module_cmd,
	NGX_HTTP_MODULE,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NGX_MODULE_V1_PADDING
};



void
ngx_pagecount_rbtree_insert_value(ngx_rbtree_node_t *temp, ngx_rbtree_node_t *node,
    ngx_rbtree_node_t *sentinel)
{
    ngx_rbtree_node_t  **p;

    for ( ;; ) {

		if (node->key < temp->key) {
			p = &temp->left;
		} else if (node->key > temp->key) {
			p = &temp->right;
		} else {
			return ;
		}

		if (*p == sentinel) break;

		temp = *p;
       
    }

    *p = node;
    node->parent = temp;
    node->left = sentinel;
    node->right = sentinel;
    ngx_rbt_red(node);
}


ngx_int_t ngx_http_handler_shm_zone_init (ngx_shm_zone_t *zone, void *data) {

	ngx_http_pagecount_conf_t *conf = zone->data;
	
	// 
	ngx_rbtree_init(&conf->sh->rbtree, &conf->sh->sentienl, 
		ngx_pagecount_rbtree_insert_value);

	
	
}


char *ngx_http_handler_count_set(ngx_conf_t *cf, ngx_command_t *cmd, void *conf) {

#if ENABLE_RBTREE

	ngx_http_pagecount_conf_t *mconf = (ngx_http_pagecount_conf_t *)conf;
	
	ngx_str_t name = ngx_string("page_count_slab_shm");
	mconf->shmsize = 1024 * 1024; // 1M
	
	
	ngx_shm_zone_t *shm_zone = ngx_shared_memory_add(cf, &name,mconf->shmsize, &ngx_http_handler_module);
	if (shm_zone == NULL) return NGX_CONF_ERROR;

	shm_zone->init = ngx_http_handler_shm_zone_init;
	shm_zone->data = mconf;
	//mconf->

	

#endif


	ngx_http_core_loc_conf_t *ccf = ngx_http_conf_get_module_loc_conf(cf, ngx_http_core_module);
	ccf->handler = ngx_http_count_handler;

	//memset(pv_table, 0, sizeof(pv_table));
	// 
	
	

	return NGX_CONF_OK;
}




